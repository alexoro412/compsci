# The First Exercise!

Welcome to the first exercise in this course. Your instructions can all be found in the TODO pane at the bottom of the IDE. There you'll find a helpful entry that says

> TODO: Start here!

Also, remember that you've got a reference solution to this exercise over in the `1.3.02-Solution-DrawAStarfield` folder! That project has the exact same TODOs, so if you get stuck on a particular part, you'll be able to get yourself un-stuck!
