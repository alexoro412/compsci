# Circles and Arcs

Before we dig into the camera/perspective/viewport awesomeness that is the rest of this lesson, let's learn one more shape that ShapeRenderer can make for us. Circles! Also, partial circles, or arcs.

To dig in, check out the TODOs!
