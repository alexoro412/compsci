# Draw a Spiral

In this exercise, you'll take a project that draws a bunch of concentric rentanges, and modify it to draw a spiral instead! This is just to get some more practice with LibGDX drawing, but also to challenge your geometric reasoning. Go hit up the TODOs if you want to give it a try!
 

# Hint below! Spoilers!

.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.



















 



```
┌────┐ ┌────┐
│┌──┐│ │┌──┐│   ┌──┐ ┌──┐ 
││┌┐││ ││┌┐││   │┌┐│ │┌┐│    ┌┐ ┌┐
││└┘││ │└─┘││   │└┘│ └─┘│    └┘ ─┘
│└──┘│ └───┘│   └──┘ ───┘
└────┘ ─────┘   
```

