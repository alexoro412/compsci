# Stick Figure

In this exercise you'll set up all the objects required for drawing in LibGDX, and will use your ShapeRenderer skills to draw a stick figure!

Check out the TODOs to get started.
