public class CityZip
{
	public String city;
	public int zip;

	public CityZip(String c, int z)
	{
		city = c;
		zip = z;
	}

	public String getCity()
	{
		return city;
	}

	public int getZip()
	{
		return zip;
	}
}
